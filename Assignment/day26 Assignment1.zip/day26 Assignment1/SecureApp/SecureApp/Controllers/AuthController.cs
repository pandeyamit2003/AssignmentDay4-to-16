﻿using Microsoft.AspNetCore.Mvc;

using Microsoft.IdentityModel.Tokens;

using SecureJWTApp.Models;

using System.IdentityModel.Tokens.Jwt;

using System.Security.Claims;

using System.Text;

namespace SecureJWTApp.Controllers
{
    [ApiController]

    [Route("auth")]

    public class AuthController : ControllerBase
    {
        [HttpGet("login")]

        public IActionResult LoginPage()
        {
            return Ok(
                "Use POST request for login");
        }


        [HttpPost("login")]

        public IActionResult Login(
            LoginModel login)
        {
            if (login.Username == "admin"
                &&
                login.Password == "Admin123")
            {
                var tokenHandler =
                    new JwtSecurityTokenHandler();

                var key =
                    Encoding.UTF8.GetBytes(
                        "ThisIsMySecretKey12345");

                var tokenDescriptor =
                    new SecurityTokenDescriptor
                    {
                        Subject =
                            new ClaimsIdentity(
                                new[]
                                {
                                    new Claim(
                                        ClaimTypes.Name,
                                        login.Username),

                                    new Claim(
                                        ClaimTypes.Role,
                                        "Admin")
                                }),

                        Expires =
                            DateTime.UtcNow
                            .AddMinutes(30),

                        SigningCredentials =
                            new SigningCredentials(
                                new SymmetricSecurityKey(
                                    key),

                                SecurityAlgorithms
                                .HmacSha256Signature)
                    };

                var token =
                    tokenHandler.CreateToken(
                        tokenDescriptor);

                return Ok(new
                {
                    token =
                    tokenHandler.WriteToken(
                        token)
                });
            }

            return Unauthorized();
        }

        [HttpGet("test")]

        public IActionResult Test()
        {
            return Ok(
                "JWT Authentication Working");
        }
    }
}