﻿using Microsoft.AspNetCore.Authorization;

using Microsoft.AspNetCore.Mvc;

namespace SecureJWTApp.Controllers
{
    [ApiController]

    [Route("secure")]

    public class SecureController
        : ControllerBase
    {
        [HttpGet("test")]

        public IActionResult Test()
        {
            return Ok(
                "Secure Controller Working");
        }

        [Authorize]

        [HttpGet]

        public IActionResult GetSecureData()
        {
            return Ok(
                "Secure API Accessed");
        }

        [Authorize(Roles = "Admin")]

        [HttpGet("admin")]

        public IActionResult AdminOnly()
        {
            return Ok(
                "Welcome Admin");
        }

        [HttpGet("admin-test")]

        public IActionResult AdminTest()
        {
            return Ok(
                "Admin API Route Working");
        }
    }
}